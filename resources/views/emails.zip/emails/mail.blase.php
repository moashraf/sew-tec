<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
	<div><h3> Order Number </h3> <h4>{{$orderNumber}}</h4></div>
	<div><h3> User Name </h3> <h4>{{$user_info->username}}</h4></div>
	<div><h3> User email </h3> <h4>{{$user_info->email}}</h4></div>
	<div><h3> User phone </h3> <h4>{{$user_info->phone}}</h4></div>
	<div><h3> User address </h3> <h4>{{$user_info->address}}</h4></div>
	</body>
</html>